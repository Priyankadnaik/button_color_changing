package com.example.user.pri2;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText ed1;
    Button b1, b2, b3;
    TextView textView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed1 = (EditText) findViewById(R.id.editText2);
        b1 = (Button) findViewById(R.id.button);
        b2 = (Button) findViewById(R.id.button4);
        b3 = (Button) findViewById(R.id.button5);
        ed1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String str = ed1.getText().toString();
                String[] sep = str.split(",");
                String c1 = new String("RED");
                String c2 = new String("GREEN");
                String c3 = new String("BLUE");
                for (int i = 0; i < sep.length; i++) {
                    if (sep[i].equals(c1)) b1.setBackgroundColor(Color.RED);
                    else if (sep[i].equals(c2)) b2.setBackgroundColor(Color.GREEN);
                    else if (sep[i].equals(c3)) b3.setBackgroundColor(Color.BLUE);

                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }
}

     /*  btn1=(Button) findViewById(R.id.button);
        btn2=(Button) findViewById(R.id.button4);
        btn3=(Button) findViewById(R.id.button5);
        edit=(EditText) findViewById(R.id.editText2);
        textView=(TextView) findViewById(R.id.textView);
        String result=edit.getText().toString();
        textView.setText(result);
        edit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                textView.setText(s);
            }

            @Override
            public void afterTextChanged(Editable s) {


            }
        });

    }
}
*/